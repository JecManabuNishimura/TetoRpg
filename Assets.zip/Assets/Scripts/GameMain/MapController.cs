using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapController : MonoBehaviour
{
    private int[,] MapData = new int[20,10];
    
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
