using UnityEditor;
using UnityEngine;

public class EffectManager : MonoBehaviour
{
    public static GameObject ExplotionEffect;
    
    public static void PlayEffect(EffectType type,Vector2 pos)
    {
        
    }
}


