using UnityEngine;

public interface ICharactor
{
    void UpdateHp();
    void Damage(int damage);
}
